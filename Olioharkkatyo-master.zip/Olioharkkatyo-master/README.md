# Olioharkkatyo CT60A2411
# Admin käyttäjä - un: admin pw: adm1n
